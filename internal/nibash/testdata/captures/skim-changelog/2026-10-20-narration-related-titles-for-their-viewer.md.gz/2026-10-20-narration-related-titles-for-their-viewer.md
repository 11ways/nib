---
title: A history line or diff names a foreign key's record only for a viewer who may read it
date: 2026-10-20
repos: zenit, zenit-cms
detect: a narrated change or revision diff shows a relation's bare key ("Team set to 7") where it showed the team's name
---

## What changed

`StandardFieldValueText` (and so plumage's `ViewerFieldValueText`) words a `BelongsTo` local key as the related
record's title only for a viewer, and only as that viewer may read it: through the source references to the related
model read, resolved as a relation picker resolves it (`RecordSourceRegistry.referenceSourceFor`: the model's
reference policy, else its default, in its reference lane), with that source's gate (`RecordSource.authorizes`) and
`referencedTitles`, its archived mark included. It used to read the related row unscoped and title it without a
reader, so a history line or revision diff named records its reader could not open. A foreign key onto anything but
the related primary key, a related model no source serves references to, a record the viewer may not read and every
value worded without a viewer read as the bare key.

`FieldValueText` gains `text(schema, field, value, reader, resolver, viewer)`; the five-argument form is the no-viewer
lane, and its default delegates the viewer form to it, so a formatter implementing only the five-argument form names
no related record (fails closed). `ChangeContext` carries the `viewer` (a new last component; the six-argument
constructor is the no-viewer context). `ChangeNarration.compose(model, change, action, values, reader)` and the CMS
revision, activity and diff pages pass their viewer.

`RecordSourceRegistry.referenceSourceFor(modelId)` is THE model's own reference rule, shared with
`EditContext.pickerSource` (which adds explicit ids and surface selections around it).
`RecordSourceRegistry.referenceTitleFor(modelId, key, chain, viewer)` is THE one-record "name a related record for
this viewer" call the standard formatter makes, and `referencedTitle(sourceId, key, chain, viewer)` its sibling for a
narrator naming a source itself: the source, its gate, then `referencedTitles`; null when no source answers, the
viewer is refused or outside the record's rows, or the lookup throws (logged, fail closed).

Localized content: the related title resolves in the viewer's locale chain, like every record source title.

## How you notice it

A history detail line or revision diff of a relation change reads its stored key for a reader who may not read the
related record, and for every narration composed without a viewer:

    expected: "Team set to Platform"
     but was: "Team set to 7"

## How to fix

Pass the viewer where the narration has one. A narrator building its own context keeps the one it was handed:

    // before
    new ChangeContext(model, change.entry(), fields, change.values(), change.reader(), change.resolver());
    // after
    new ChangeContext(model, change.entry(), fields, change.values(), change.reader(), change.resolver(),
        change.action(), change.viewer());

A caller wording a value for a person passes them: `values.text(schema, field, value, reader, resolver, access)`.
A narrator naming one related record itself calls `RecordSourceRegistry.INSTANCE.referenceTitleFor(...)` (or
`referencedTitle(...)` for a source it names) rather than repeating the lookup, gate and failure handling, and falls
back to its own words when it answers null. A related model whose title a history line should show declares a record
source under its model id or a reference policy (`RecordSource.Builder#referencePolicy()`).

## Affects

Narrators that build a `ChangeContext` of their own (Arcana's `FinanceNarration`), code calling `FieldValueText.text`
for a person, and models referenced by a foreign key whose model registers no record source.
