---
title: MCP tools name records by 8-character handles; a record subject needs an indexed handle column
date: 2026-10-20
repos: protoblast, zenit, zenit-ai, zenit-auth, zenit-semantics, zenit-folio, zenit-wiki, switchboard, quirkyquarters
detect: Tool '<name>': subject type <model> cannot resolve handles
---

## What changed

- protoblast `Uuids.handle(id)` is a record's short handle (its last 8 hex digits); `Uuids.isHandle`/`handleOf` read
  one. `DateStyle.ISO` words a day as "2026-10-16" and a moment as "2026-10-16 11:17" (24-hour, any locale), also as
  `{$at :datetime style=iso}`.
- zenit `UuidField.builder(name).withHandle()` keeps the handle in an indexed column `<key>_handle` beside the key,
  stamped on insert. `MigrationBuilder.addRecordHandle(table, keyColumn)` adds, fills and indexes it on an existing
  table (`dropRecordHandle` is its down) and must run in a transaction-free migration;
  `TableBuilder.recordHandle(keyColumn)` adds it to a table created in the same migration.
- On a surface that accepts handles (MCP tools), a subject key or a record id input that is a handle resolves to the
  one record the caller may read that it names. Several readable matches refuse with the new
  `ZenitRefusalReason.AMBIGUOUS`; a record the caller cannot read never counts and never shows. Id inputs are
  declared with `OperationForms.recordId(s)` and read with `OperationCall.recordId(s)(source, text)`.
- zenit-ai `McpToolContext.text()` spells ids as handles, instants as office-clock "YYYY-MM-DD HH:MM", sizes in words
  and versions as "v8"; `initialize` names the office zone once. Building an MCP tool over a model whose UUID key
  keeps no handle column is refused.
- New transaction-free migrations fill the column on existing rows: zenit-folio M011 (`folio`), zenit-wiki M012
  (wiki pages), zenit-semantics M022 (subjects, references), zenit-auth M027 (share links), switchboard M007 (runs,
  run files).
- Folio, wiki, switchboard and QuirkyQuarters MCP answers print handles and office-clock stamps; a successful write
  answers in one line; wiki edit and create no longer repeat the page; `folio_types` takes `type` and serves the
  runtime TypeScript as the resource `folio://runtime/<contract>.d.ts`; switchboard run logs show the last 40 lines
  with `log_from`. Wiki MCP refusals read "Refused (invalid): ..." instead of "INVALID: ...".
- `FolioGallery.Listing` gains `type`; `WikiOperations.Listing` holds `Listed` rows and `pageCount`.

## How you notice it

`IllegalStateException: Tool 'folio_read': subject type zenitfolio:folio cannot resolve handles; key its model by a
UUID declared withHandle(), or give its read path withHandles(...)` when an MCP host builds its tools. A migration
using `addRecordHandle` inside a transaction is refused before it runs. An agent prompt, script or test that parses
full UUIDs, ISO instants, "folio_id:"/"head:" fact lines, `run <uuid>: <status>`, `expires_in: 900 seconds` or
"INVALID:" prefixes out of MCP text no longer matches. Code constructing `FolioGallery.Listing` or
`WikiOperations.Listing` no longer compiles.

## How to fix

1. Declare the key: `UuidField.builder("id").withHandle().build()`.
2. Add a transaction-free migration: `super(version, name, false)`, `builder.addRecordHandle("<table>", "id")` in
   `up`, `builder.dropRecordHandle("<table>", "id")` in `down`.
3. In MCP answers print `context.text().id(uuid)`, `context.text().moment(instant)` and `context.text().bytes(n)`
   instead of `uuid.toString()`, `instant.toString()` and raw byte counts. URLs, share links, resource URIs and
   download names keep the full id.
4. Id inputs: declare `OperationForms.recordId(name, help, required)` and read `call.recordId(source, text)` instead
   of `UUID.fromString`.
5. A typed (non-model) subject whose keys are UUIDs declares `SubjectReadPath.withHandles(...)`; without it a handle
   reads as not found.
6. Deployments run the new migrations on their next boot; they fill existing rows, so nothing else is needed.

## Affects

Projects that host MCP tools or embed zenit-folio, zenit-wiki, zenit-semantics or zenit-auth (their migrations run
on boot), and agent prompts or tests that parse ids or stamps out of MCP text.
