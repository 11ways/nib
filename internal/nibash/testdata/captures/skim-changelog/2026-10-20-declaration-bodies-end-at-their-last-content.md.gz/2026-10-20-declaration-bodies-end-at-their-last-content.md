---
title: A pretty-printed template { } or tag-body snippet { } ending in a slot, print or text no longer renders a trailing space
date: 2026-10-20
repos: hawkeye
detect: A component host that held only a trailing " " text node is now empty (matches :empty), or a rendered HTML or text baseline lost one trailing space
---

## What changed

Hawkeye's parser dropped the whitespace right after a declaration body's opening `{` as formatting, but stopped at the
first `{# #}` comment and kept the whitespace before its closing `}` (only newline-formatted element-only endings were
already trimmed). A pretty-printed body ending in text-capable content (a `<slot>`, a `{{ print }}`, a
`{% render %}`, plain text, or a `{% if %}` that can render text) therefore rendered one trailing space text node
(plain text kept its newline and indentation verbatim), and a body opening with a comment rendered a leading one.

Now both braces follow one rule: the run between the opening `{` and the body's first content, and the run between
its last content and the closing `}`, is formatting and renders nothing. Each run is whitespace and markup comments
`{# #}`, up to the nearest element, print, statement, `<!-- -->` comment or non-whitespace text. This applies to a
tag's `template { ... }` and a tag-body `snippet name(...) { ... }`, written on one line or many. Consequences:

- A component whose template ends in an empty `<slot>` leaves its host with no child text or element node, so the
  host matches `:empty` (HTML comment markers do not count). The same holds when a `{# #}` comment opens the body.
- A flex or grid host no longer gets a gap, or an extra anonymous item, from the indentation before `}`.
- A body ending in a print or plain text ends at its last character: `x`, not `x ` or `x\n    `.
- One-line endings change too: `template { <b>x</b> }` no longer renders a trailing space after `</b>`.

Untouched: whitespace between content inside the body (`{{ a }} {{ b }}` still renders `a b`); whitespace inside the
elements written within the declaration; `pre`/`textarea`/`script`/`style` content; slot fallbacks; projected
content; printed values (`{{ "Label " }}` keeps its space). "Inside elements" means elements within the declaration
itself: a snippet rendered into a caller's `<pre>` still has its own body boundaries trimmed. Source ranges: the first
and last literal text nodes of a body now start and end at their trimmed text; every other location, and every
diagnostic, is unchanged.

## How you notice it

A rendered-HTML or text-content assertion or baseline that captured the trailing space (`<my-card>Hello </my-card>`,
`textContent` equal to `"Label "` from literal body text) now sees `<my-card>Hello</my-card>` / `"Label"`. A test that
expected a host with an empty slot to be non-empty now finds it `:empty`. A workaround that wrote a template on one
line, or styled `:empty` hosts by another means, is no longer needed.

## How to fix

Update the baseline to the trimmed output. If a body relied on a boundary space to separate it from what follows the
host (`template {Hello }` followed by `world` outside the host now reads `Helloworld`), put a real separator back:
a literal space in the parent template, or an explicit printed space at the end of the body. CSS `gap` or margin is
not a fix: it restores only the visual spacing, not the copied or accessible text.

```html
<!-- before: the space came from the indentation before } -->
template {
    {{ label }}
}
<!-- after: same source, renders "label" with no trailing space; a needed separator goes in the parent, or: -->
template {
    {{ label }}{{ " " }}
}
```

A one-line template written only to dodge the trailing space can be pretty-printed again.

## Affects

Every project rendering hawkeye components whose `template { }` or tag-body snippet ends in a slot, print, render,
plain text or a text-capable `{% if %}`/`{% each %}`, and projects whose tests or surface baselines compare rendered
HTML or text of such hosts.
