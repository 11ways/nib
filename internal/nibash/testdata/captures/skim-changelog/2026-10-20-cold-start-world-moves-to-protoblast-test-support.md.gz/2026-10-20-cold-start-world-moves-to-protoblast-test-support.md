---
title: ColdStartWorld moves to protoblast-test-support, the one test-side home naming BlastAutoLoadInit
date: 2026-10-20
repos: protoblast, zenit, zenit-cms, zenit-forms, zenit-media, zenit-widget, zenit-editor, zenit-wiki, hawkeye, plumage
detect: cannot find symbol ColdStartWorld or FreshClassWorld in be.elevenways.zenit.test.support
---

## What changed

- `be.elevenways.zenit.test.support.ColdStartWorld` and `FreshClassWorld` are gone. Their mechanism lives in
  protoblast-test-support as `be.elevenways.protoblast.testsupport.coldstart.ColdStartWorld`: `testClasspath` and
  `fresh` (FreshClassWorld's two methods), `compile`, `open` and `Session` as before.
- `compile(dir, index, fixtures, needed...)` takes the stand-in index source as its own argument, and
  `testClasspath` requires the code sources of Blast and the generated index itself: a test no longer passes
  `BlastAutoLoadInit.class` or `Blast.class`, nor a `"BlastAutoLoadInit"` fixture entry.
- `ColdStartWorld.INDEX` is the index's binary name. Besides `Blast`, `ColdStartWorld` is the only class the
  static-index-waits rule lets name `BlastAutoLoadInit`; any other class naming it (a class literal included) is a
  finding.
- New: `Session.holding(type)`, `letGo()` and `arrivals()` hold one fixture initializer at
  `ColdGate.holdInitializer()`; `invoke` and `invoking` take string arguments.
- Every cold-start test in zenit, zenit-cms, zenit-forms, zenit-media, zenit-widget, zenit-editor, zenit-wiki and
  plumage now uses it; hawkeye's template autoload journey compiles its stand-in index through it.

## How you notice it

- `error: package be.elevenways.zenit.test.support does not exist` or `cannot find symbol ... ColdStartWorld` /
  `FreshClassWorld`
- `error: no suitable method found for compile(Path,Map<String,String>,Class<BlastAutoLoadInit>,...)`
- guard-report: `<Test> names BlastAutoLoadInit, the index's internals`

## How to fix

Add `testImplementation libs.protoblast.test.support` where the test set does not have it yet.

Before:

```java
import be.elevenways.protoblast.generated.BlastAutoLoadInit;
import be.elevenways.zenit.test.support.ColdStartWorld;

world = ColdStartWorld.compile(compiled, Map.of("ColdReads", READS, "BlastAutoLoadInit", INDEX),
    BlastAutoLoadInit.class, Blast.class, RecordSource.class);
try (URLClassLoader loader = FreshClassWorld.over(FreshClassWorld.testClasspath(BlastAutoLoadInit.class, X.class)))
```

After:

```java
import be.elevenways.protoblast.testsupport.coldstart.ColdStartWorld;

world = ColdStartWorld.compile(compiled, INDEX, Map.of("ColdReads", READS), RecordSource.class);
try (URLClassLoader loader = ColdStartWorld.fresh(ColdStartWorld.testClasspath(X.class)))
```

`BlastAutoLoadInit.class.getName()` becomes `ColdStartWorld.INDEX`.

## Affects

Test suites with cold-start or first-touch tests (a stand-in autoload index or a fresh class world).
