---
title: PlacementSurface declares acceptsRecordHandles(), with no default; ZenitRefusalReason gains AMBIGUOUS
date: 2026-10-20
repos: zenit, zenit-cms, zenit-widget, zenit-ai, hohenheim
detect: does not override abstract method acceptsRecordHandles() in PlacementSurface
---

## What changed

`PlacementSurface` gained `boolean acceptsRecordHandles()` with no default, beside `redrawsRefusedForm()`. A surface
answering true lets the operation pipeline read a subject key or record id input that is a short record handle
(`Uuids.handle`) as the one record the caller may read that it names. `McpToolSurface.MCP_TOOL` answers true;
`ZenitPlacementSurface`, `CmsPlacementSurface` and `WidgetPlacementSurface` answer false, so URLs, the HTTP API,
admin actions and widgets keep full ids. `ZenitRefusalReason` gained `AMBIGUOUS` (422, recovery NEVER).

## How you notice it

`error: <anonymous ...> is not abstract and does not override abstract method acceptsRecordHandles() in
PlacementSurface`, from a class or anonymous surface (often in a test). `error: the switch expression does not cover
all possible input values` on an exhaustive switch over `ZenitRefusalReason`.

## How to fix

State the fact on the surface. Before:

```java
new PlacementSurface() {
    @Override public boolean redrawsRefusedForm() { return false; }
};
```

After:

```java
new PlacementSurface() {
    @Override public boolean redrawsRefusedForm() { return false; }
    @Override public boolean acceptsRecordHandles() { return false; }
};
```

Answer true only for a surface whose callers are models reading compact text. Add `AMBIGUOUS` to exhaustive
switches over `ZenitRefusalReason` (Hohenheim's `ApiConduits` rethrows it to core's edge).

## Affects

Projects and tests that implement `PlacementSurface` or switch exhaustively over `ZenitRefusalReason`.
