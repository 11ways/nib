---
title: Browser-test failure captures cover every open page; tests close what they open through closeAfterTest
date: 2026-10-20
repos: protoblast, hawkeye, textum, zenit, zenit-forms, zenit-cms, zenit-auth, zenit-wiki, zenit-editor, plumage, zenit-folio, arcana, switchboard
detect: build/test-results/browserTest/screenshots/<Class>-<method>.png is no longer written
---

## What changed

A failing browser test is captured by protoblast's `FailureCaptureExtension`, which hawkeye's
`HawkeyeBrowserTestBase`, `ProtoblastBrowserTestBase` and `TextumBrowserTestBase` declare. It shoots every open page
of every browser and profile context `PlaywrightEngine` launched (second tabs, popups, browsers a test launches
itself), not only the base's own page, and writes an index with each page's URL, title, console and page errors. An
untouched `about:blank` page is listed as blank, not shot. A failed test body is captured as `<Class>-<method>`, a
failed `@BeforeEach`/`@AfterEach` method as `<Class>-<method>-beforeEach` or `-afterEach`.

`FailureCaptureExtension.closeAfterTest(resource)` registers a test-owned browser, context or page and closes it after
the capture ran; every workspace browser test uses it instead of a try-with-resources or `finally` close.

## How you notice it

- `build/test-results/browserTest/screenshots/` holds `<name>-page<N>.png` and `<name>.pages.txt` instead of
  `<Class>-<method>.png` (hawkeye) or `<method>.png` (protoblast, textum).
- A test that closes its own browser or context in a `finally` or try-with-resources gets no shot of those pages
  when it fails.
- `closeAfterTest` called outside a test method throws `IllegalStateException`.

## How to fix

- Read `<name>.pages.txt` first to find the page file you drove. A script or CI step that collected
  `<Class>-<method>.png` collects `<Class>-<method>*-page*.png` and `<Class>-<method>*.pages.txt`.
- In a browser test, before:

  ```java
  try (BrowserContext other = browser.newContext()) {
      // ...
  }
  ```

  after (static import `be.elevenways.protoblast.testsupport.browser.FailureCaptureExtension.closeAfterTest`):

  ```java
  BrowserContext other = closeAfterTest(browser.newContext());
  // ...
  other.close();
  ```

  The trailing close keeps the passing path unchanged and is harmless twice. Move a resource's close out of a
  `finally`; settings resets and servers stay there. Class-level resources still close in `@AfterAll`.
- A project base class with its own failure screenshot drops it and declares
  `@ExtendWith(FailureCaptureExtension.class)` after its lifecycle extension. Launch browsers through
  `PlaywrightEngine` so their pages are captured.

## Affects

Projects or CI scripts that read failure screenshots by name, browser tests outside the workspace that close
test-owned browsers, contexts or pages in the test body, and browser-test bases outside the workspace.
