---
title: Model.resolveDisplayTitles titles a page of rows at once; every title method but it and the row hook is final
date: 2026-10-20
repos: zenit, zenit-cms, zenit-ai, zenit-folio, zenit-voxel, hohenheim
detect: overridden method is final (Model.getDisplayTitle, resolveDisplayTitle with a reader, resolveTitleBeneathParent), or a related read per row
---

## What changed

`Model.resolveDisplayTitles(rows, chain, reader)` is THE seam for titles of a page of rows as one reader reads them,
and every title path reaches it: `getDisplayTitle(row)`, `getDisplayTitle(row, chain)`, `getDisplayTitle(row, chain,
reader)`, `resolveDisplayTitle(row, chain, reader)` and the new `getDisplayTitles(rows, chain, reader)` (a page of
titles with the `"{ModelName} #{pk}"` fallback) are `final` and ask it, a single row as a page of one. Its default
answers each row through `resolveDisplayTitle(row, chain)`, the per-row hook for a title computed from the row's OWN
fields. Those two are the only title methods a model overrides, so no override is skipped by a path that does not pass
through it (an override of the one-argument `getDisplayTitle` used to be skipped by every record heading, crumb,
confirmation and toast). `resolveTitleBeneathParent(row, chain)`, a crumb's title beneath its parent record's crumb, is
`final` too: it is the row hook's own-field title and reads no related record, so it never names one the viewer may
not read. `RecordSource.items(rows, chain, access)` (new, the page form of `item`),
`referencedTitles`, the query endpoint, facet catalogs, history subject titles (`HistoryProjections`, one call per page
and model), the legacy activity subjects and zenit-cms's grouped and tree lists, attention feed and command palette
call it once per page.

A model whose title names another record (an owner, a parent) overrides `resolveDisplayTitles` and reads the related
records of ALL rows in one read authorized for the reader, through `RecordSource.referencedTitles` of the related
model's registered source; a related record the reader may not read names nothing. A `null` reader is the
context-less lane: such a title reads no related record. `resolveDisplayTitle(row, chain)` has no reader, so it
must not read a related record either.

Hohenheim's build and environment titles moved onto it: a build reads "{app} deploy" (microcopy
`build_operation.deploy_title`, in the reader's language), an environment "{project} / {name}", each only for a
reader who may read the app or project, else the record's own fields. zenit-ai's model endpoint
(`ModelProviderLinkModel`) names its model and provider as a fact run (`Texts.factRun`) the same way, both
related tables read once per page and only for a reader of the AI catalog; without one it is the pk fallback
("ModelProviderLink #id").

zenit-voxel's asset source (its label, else its path) and core's `ActionModel` title through the per-row hook, so
a voxel source's record heading, crumbs, confirmations and toasts read its label as its picker does. zenit-folio's
folio title moved onto `resolveDisplayTitles`, but it is NOT batched yet: each folio of a page is still read on its
own (`Folios.read` per row), so a page of folios or of history lines naming folios reads one folio per row.

A record source whose words read beyond the row declares `RecordSource.Builder.texts(PageTexts)` instead of
`titleFor`/`subtitle`/a per-row `icon`: one call words the page's readable rows (`RowTexts(title, icon, subtitle)`,
a null title falling back to the model's, a null icon to the source's). Declaring both is refused when the source
resolves. zenit-cms's activity sources (`ActivitySources`) word a page of actions from one `History.entries` batch
and one read of the listed changes, so a dashboard's recent-activity card reads the same few queries at any size.

A record source whose title alone reads beyond the row declares `RecordSource.Builder.titles(PageTitles)`: one call
titles the page's readable rows (a null title falling back to the model's); `titleFor` is its per-row form. zenit-cms's
record sources of a resource with a title mapping (its panel, picker and model sources: `/zn/records`, pickers,
widgets) title a page through `PartsReads.recordTitles`, so the rows the mapping leaves to the model are titled in one
`Model.getDisplayTitles` call per page, where they were titled one row at a time.

A record's own surfaces title it for their viewer: `Model.getDisplayTitle(row, chain, reader)` (the reader-aware title
with the readerless pk fallback) backs `PanelResource.recordTitle(record, reader)` and
`PartsReads.recordTitle(entry, record, reader)`, which the record heading, document title, breadcrumbs, previews,
delete and trash confirmations, lifecycle toasts and create/save/delete toasts all pass. The 2-argument
`PartsReads.recordTitle(entry, record)` remains for a lane with no viewer and names no related record.

Localized content: the seam passes the reader's locale chain; a title worded through microcopy resolves it in that
chain, and localized display fields resolve through it as before.

## How you notice it

A model overriding `getDisplayTitle(Row)`, `getDisplayTitle(Row, LocaleChain)`,
`getDisplayTitle(Row, LocaleChain, AccessContext)`, `resolveDisplayTitle(Row, LocaleChain, AccessContext)` or
`resolveTitleBeneathParent(Row, LocaleChain)` no longer compiles:

    error: getDisplayTitle(Row) in VoxelAssetSourceModel cannot override getDisplayTitle(Row) in Model
      overridden method is final

A list, history page or relation column of a model whose override of `resolveDisplayTitle(row, chain)` reads a
related record issues one query per row; `DatasourceProbe.queriesAgainst(relatedModel)` grows with the page:

    expected: <1> but was: <6>

A reader without access to the related record sees its name in a title.

A model endpoint (`ModelProviderLinkModel`) titled without a reader (a background job, a log line, a test calling
`getDisplayTitle(row)`) now reads `ModelProviderLink #<id>` where it read its model and provider: only a reader of the
AI catalog is told which records it joins.

## How to fix

Move a title computed from the row's own fields onto the per-row hook:

    // before
    @Override
    public @NonNull String getDisplayTitle(@NonNull Row row) {
        String label = Texts.trimmedOrNull(row.get(LABEL));
        return label != null ? label : super.getDisplayTitle(row);
    }
    // after
    @Override
    public @Nullable String resolveDisplayTitle(@NonNull Row row, @Nullable LocaleChain chain) {
        String label = Texts.trimmedOrNull(row.get(LABEL));
        return label != null ? label : super.resolveDisplayTitle(row, chain);
    }

Move a related read into `resolveDisplayTitles` and delete any override of the reader form of
`resolveDisplayTitle`, which now asks `resolveDisplayTitles` itself:

    // before
    @Override
    public @Nullable String resolveDisplayTitle(@NonNull Row row, @Nullable LocaleChain chain) {
        Row owner = Models.get(OwnerModel.class).findById(row.get(OWNER_ID));
        return owner == null ? super.resolveDisplayTitle(row, chain) : owner.get(OwnerModel.NAME) + " / " + ...;
    }
    // after
    @Override
    public @NonNull List<@Nullable String> resolveDisplayTitles(@NonNull List<Row> rows, @Nullable LocaleChain chain,
                                                                @Nullable AccessContext reader) {
        RecordSource<?> owners = RecordSourceRegistry.INSTANCE.byId(OwnerModel.MODEL_ID);
        Map<String, String> named = reader == null || owners == null || !owners.authorizes(reader) ? Map.of()
            : owners.referencedTitles(ownerIdsOf(rows), chain, reader);
        // one title per row: the owner's where named, else super.resolveDisplayTitle(row, chain)
    }

Translate a page of rows with `source.items(rows, chain, access)` instead of a loop of `source.item(...)`, and title
a page of records with `model.getDisplayTitles(rows, chain, access)`, `PanelResource.recordTitles(records, access)`
or `PartsReads.recordTitles`/`recordTitleTexts(entry, records, access)` instead of a loop of their one-record forms.
Title one record for a viewer with `model.getDisplayTitle(row, chain, access)`, `PanelResource.recordTitle(record,
access)` or `PartsReads.recordTitle(entry, record, access)`; their readerless forms are the no-viewer lane only.

## Affects

Models overriding a now-final title method, models whose title names another record, code that titles a page of rows
or records one at a time, record sources whose per-row title, icon or subtitle reads other tables, readerless
`recordTitle` callers on a viewer's path, and anything titling a record without a reader (a model endpoint is then the
pk fallback, a build its own fields, an environment its bare name).
