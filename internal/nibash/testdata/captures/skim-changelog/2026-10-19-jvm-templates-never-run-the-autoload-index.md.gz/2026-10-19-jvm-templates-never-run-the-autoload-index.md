---
title: A JVM template's static initializer no longer runs the autoload index; index-filled reads run it themselves
date: 2026-10-19
repos: hawkeye, protoblast, zenit, zenit-cms, zenit-widget, zenit-forms, zenit-media, zenit-editor, plumage
detect: A JVM test or tool rendering a template before anything ran Blast.ensureAutoLoaded() misses an index-registered member
---

## What changed

- hawkeye: every generated template class called `Blast.ensureAutoLoaded()` from its static initializer. That call
  now sits under `if (Blast.IS_TEAVM)`, so javac folds it away in the JVM compile: a JVM template's `<clinit>` never
  waits on the autoload index (a class-init deadlock once another thread runs the index and the index needs that
  template class). TeaVM output keeps the call.
- protoblast: `DominoCustomElement`'s tag registries are `KeyedRegistry.autoLoaded`, so `getCreatorOf`/`getClassOf`
  run the index first: a JVM render finds another module's hand-written custom element without help.
- hawkeye: the generated tier of `ClassPropertyAccessorRegistry`/`ClassPropertyMutatorRegistry` is
  `RegistryFeed.AUTOLOAD_INDEX`, so an untyped path read of another module's `@HawkeyeClass` runs the index first.
- protoblast: `Subprocess.ofJavaMain(classPathFirst, mainClass, args...)` starts a fresh JVM with entries ahead of
  this JVM's class path (a test fixture shadowing the generated index).
- The framework registries index members fill and template functions read now load on read: zenit `Stylesheets`
  (`Registry.autoLoaded`), `RecordSourceRegistry` and `RenderDecorators` (their reads run the index outside their
  monitor; registration never does); zenit-cms `PanelSlots`; zenit-widget `WidgetRegistry` and
  `WidgetCategoryRegistry`; zenit-forms `ConfigSpecFamilies` and `ControlFactories`; zenit-media `MediaPresets`
  (legacy names included); zenit-editor `RichTextProfiles`; zenit `RecordLinks.PAGES`; zenit-forms
  `FormEntryRendererRegistry` and `FieldDiffRegistry`; plumage `ThreadActions`, `ThreadItemKinds`,
  `ThreadItemStates` and `ThreadPartKinds`. A first render before any boot sees their members.
- zenit-widget: `WidgetAccess.setResolver(...)` is gone; the resolver is the seam `WidgetAccess.SEAM`
  (`PlatformSeam<WidgetAccess.Resolver>`), so a read before boot runs the index instead of finding nothing, and a
  request with no resolver installed throws (`IllegalStateException`) instead of rendering an empty widget.
- protoblast: `ClassKeyedRegistry.put`/`replace` force a subclass's `ensureDefaults()` before taking the write
  monitor, so a defaults holder registering from its initializer cannot deadlock against an external registration.

## How you notice it

Before, rendering ANY template on the JVM ran the whole index as a side effect. Code that read a registry the index
fills, made with `Registry.create`/`KeyedRegistry.create` (`RegistryFeed.DECLARATIONS`) or kept in a private static
collection, and that only worked because a template had been loaded first, now sees that registry empty when nothing
else ran the index: a JVM test without the zenit server boot, a CLI tool, a standalone hawkeye host. Zenit's server
boot (`ServerZenitRuntime`) runs the index before serving, so a booted application sees no difference.

## How to fix

Make the registry the index fills read through the index, never rely on a template having loaded:

```java
// before
private static final Registry<Entry> ENTRIES = Registry.create(MyIds.id("entry"));
// after
private static final Registry<Entry> ENTRIES = Registry.autoLoaded(MyIds.id("entry"));
```

`KeyedRegistry.autoLoaded` and `ClassKeyedRegistry` with `RegistryFeed.AUTOLOAD_INDEX` are the keyed forms. A read
outside a registry calls `Blast.ensureAutoLoaded()` from the READ, never from a static initializer.

A code path that installed a widget access resolver itself:

```java
// before
WidgetAccess.setResolver(conduit -> myContext(conduit));
// after
WidgetAccess.SEAM.install(conduit -> myContext(conduit));
```

## Affects

Projects with a registry or static collection filled from a `@BlastAutoLoad` class and read on the JVM outside the
zenit server boot (unit tests, offline tools, standalone hawkeye renders), and any caller of
`WidgetAccess.setResolver`. The framework's own registries of this kind listed above need nothing.
