---
title: Unsaved form changes are one hawkeye fact; leaving an edited form asks first
date: 2026-10-20
repos: hawkeye, plumage, zenit-forms, zenit-cms, zenit-widget
detect: A browser test that edits a form and then navigates away times out or stays on the page (a dialog was dismissed)
---

## What changed

hawkeye's `Form.trackChanges` compares a form's values with the values it loaded (or last saved). While they differ,
the form carries `data-hwk-unsaved`, the statekey `hawkeye.form.unsaved` is true on the nearest provider above it, and
soft navigation (a link, Cancel, Back, another form's submit) and the browser's unload prompt ask "Leave this page?
Your changes are not saved." first. Typing a value and typing the original back is clean again; the form's own submit
is never asked about.

- Every zenit-forms form body (`zf-form-scope`, so every zenit-cms create, edit, action-input and page-action form)
  and the wizard track themselves. zenit-cms' settings editor joins each group's rows as they load.
- A refused save (`FormState.refused`) stays unsaved until a save succeeds.
- Every save lane records the values it SENT (a soft submit, a typed `:action`, a scripted lane through
  `FormChanges.collectForSave`). A success makes exactly those the baseline, so typing done while the save was in
  flight stays unsaved, and an answer that would replace it asks first. A failed, refused, declined or superseded save
  keeps the old baseline.
- Every edit renews the question: an edit made after the reader accepted leaving is asked about again.
- Controls tied to the form through `form=` are tracked; a tracked part that is removed leaves the baseline.
- A control marked `data-hwk-untracked` is left out (zenit-forms' fold state, the settings search's `q`).
- `NavigationProtection.Guard` moved to `be.elevenways.hawkeye.common.NavigationGuard`, registered with
  `Hawkeye.getGlobalInstance().protectNavigation(guard)` from any source set (a no-op on the server), with new defaults
  `carriedBy(form)`, `carried()`, `carriedSaved()` and `carriedEnded(rendered)`.
- Cancel on an edited zenit-cms form asks before leaving, like any soft navigation. Whether Cancel should discard
  without asking is not decided yet.
- The question is the microcopy key `leave_unsaved` (scope `navigation`) in the page's locale chain; plumage ships it
  in English and Dutch, hawkeye carries the English fallback.

## How you notice it

- A Playwright test that edits a zenit-cms or zenit-forms form and then clicks a link, Cancel or Back without saving
  stays on the page: Playwright dismisses dialogs by default, so the leave question keeps the page, and the next
  wait times out.
- Code that imports `be.elevenways.hawkeye.browser.NavigationProtection.Guard` no longer compiles: `cannot find
  symbol ... Guard`.
- A host's scripted save that collects with `collectFormData` and then calls `Form.saved(form)` marks typing done
  during the save as saved.

## How to fix

- A test that leaves on purpose accepts the question, or saves first:

  ```java
  page.onceDialog(Dialog::accept);
  page.locator("a.cancel").click();
  ```

  Never disable the guard to make a test pass.
- `NavigationProtection.Guard` becomes `NavigationGuard` (`be.elevenways.hawkeye.common`).
- A custom form opts in from a tag inside it, in its `@mount`: `Form.trackChanges(this, unsavedAtLoad)`
  (`unsavedAtLoad` true for a render that shows a refused submission again).
- A scripted save lane collects what it sends with `DominoFormData sent = FormChanges.collectForSave(form);` instead
  of `collectFormData`, then calls `FormChanges.saved(form)` (`Form.saved` in a template) once the save succeeded and
  before it navigates.
- A host's own filter or fold input inside a tracked form gets `data-hwk-untracked`.
- A reader outside the form (a draft bar) declares `public state hawkeye.form.unsaved as unsaved: Boolean = false`
  and its host provides it on a common ancestor: `state:hawkeye.form.unsaved={% false %}`. Never a private
  `event:input`/`event:change` flag.

## Affects

Projects with browser tests that leave edited zenit-cms or zenit-forms forms, projects with their own navigation
guards, and hosts that save forms through their own scripted lane.
