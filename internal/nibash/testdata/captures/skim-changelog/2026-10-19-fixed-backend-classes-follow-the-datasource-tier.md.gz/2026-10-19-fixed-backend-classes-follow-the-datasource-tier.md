---
title: A test class bound to one non-default backend is SKIPPED outside --datasources all
date: 2026-10-19
repos: zenit, zenit-auth
detect: a default unit lane reports tierSkipped for Couchbase, Firebird, MongoDB, MySQL, MariaDB or CockroachDB where those classes ran before
---

## What changed

zenit's test support (`zenit-test-support`, `be.elevenways.zenit.orm.TestDatasources`) applies the datasource tier
to every non-default backend's own accessor, not only to `allDatasources()` cases. The shared-container getter of
MySQL, MariaDB, CockroachDB, Firebird, MongoDB and Couchbase checks the tier first. So do `mysql()`, `mariadb()`,
`cockroachdb()`, `firebird()`, `firebirdContainer()`, `mongodb()`, `newMongo(...)`, `couchbase()`,
`newCouchbase(...)` and `couchbaseContainer()`. Outside the tier they throw the tier skip
(`SKIPPED (<backend>): not requested by datasource tier default`) before any container starts.

- A class that opens such a backend in `@BeforeAll` (`QueryBuilderAdvancedTest_Couchbase`, `Couchbase*Test`,
  zenit-auth's `SessionRevocationRaceTest_Couchbase`/`_Mongo`, `AccountRekeyMigrationTest_Firebird`) is SKIPPED
  whole in the default tier. A method that opens one in its body is SKIPPED alone.
- `zenit-dev test --datasources all` (the `zenit.test.datasources` plugin forwards it) runs them as before.
- SQLite, PostgreSQL and DuckDB are unchanged.

## How you notice it

The default unit lane runs fewer tests, and the result's `tierSkipped` counts these backends. zenit's default lane
no longer starts the Couchbase, Firebird, MongoDB, MySQL, MariaDB or CockroachDB containers for these classes.

## How to fix

Nothing to change in test code. A change to a backend implementation is proven with
`zenit-dev test --datasources all` on the classes `zd_affected` selects. zd_affected names that requirement when a
`Datasource` implementation changed. A module whose fixed-backend classes must run applies
`alias(libs.plugins.zenit.test.datasources)`, or the tier stays `default` and they never run.

## Affects

Every repo whose tests call those `TestDatasources` accessors: zenit and zenit-auth today.
