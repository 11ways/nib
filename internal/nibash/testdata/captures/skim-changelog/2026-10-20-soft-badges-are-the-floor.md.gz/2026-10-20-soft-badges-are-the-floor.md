---
title: pl-badge is a soft tinted pill by default; an attention count is tone="count", nav attention metrics included; boolean list cells are marks
date: 2026-10-20
repos: plumage, zenit-cms, zenit-notifications, zenit-folio, arcana, hohenheim
detect: A pl-badge without a tone attribute is tinted instead of filled, a count badge reads tone="count", a pl-nav-item-metric tone="attention" holds a pl-badge, or a boolean list cell shows a check mark instead of a "Yes" pill
---

## What changed

`pl-badge`'s `tone` is now the typed `BadgeTone` (plumage) and defaults to `quiet`: a badge that names no tone wears
its variant's tint as ground and its `-strong` step as label (the design boards' status pills). The tint is composed
OPAQUELY on the raised surface rather than painted translucent, so the label holds 4.5:1 on every surface, a selected
or hovered table row included (a translucent tint fell to 4.14:1 on a selected plain-table row). `tone="solid"`
keeps the filled pill (the role as ground, its `-text` step as label) for a pill asked to shout by name.

An attention count is its own kind, `tone="count"` (`BadgeTone.COUNT`): it reads filled for that one reason, in the
role `variant` names (the chrome `secondary` and `outline` stay their quiet pill in every tone), and a count site
never spells `solid`. The CMS sidebar count (`cms-nav-badge`, destructive), the notification inbox count (primary),
a folio slide's violation flag (destructive), Arcana's active-filter count and the CMS list's active-filter counts
(the filter toggle's `[data-cms-filter-count]` and each filter axis trigger's `[data-cms-filter-axis-count]`,
formerly grey `secondary` pills; all at the default primary) use it, so every active-filter count renders alike.

`pl-nav-item-metric tone="attention"` (the rail's "3 new") keeps its typed attribute but no longer paints a pill of
its own: it renders `pl-badge tone="count" size="sm"` around its words, so the count kind has one paint. The pill is
the badge's 18px small capsule (6px side padding, was 8px). A muted `default` metric is unchanged. An attention
metric always draws its pill, an empty one included: render it only with something to count, as every consumer does.

A `color-set` keeps its categorical look in every tone and variant (named and numeric sets alike); a filled tone no
longer outranks it. `secondary` and `outline` pills look the same as before.

zenit-cms list cells for a `BooleanField` render `cell/boolean-mark` (a `pl-state-glyph`: a success `circle-check`
for true, a neutral `circle-xmark` for false, the yes/no word spoken and shown as its tooltip) instead of
`cell/boolean-badge`'s worded pill; `CmsTemplateIds.CELL_BOOLEAN_BADGE` is now `CELL_BOOLEAN_MARK`. The activity
detail verb and the revision marks carry their glyph through the badge's `icon` attribute (`pl-icon.leading`).

`pl-calendar-view`'s week tab stop, when no cell the user focused is shown, skips an all-day cell its records fully
cover: it takes the nearest day to today (or to the week's first day) with a free all-day lane. A cell the user
focused keeps the stop; with every day covered it falls to the first time slot. Plumage's browser tests run on a
clock pinned to 2026-10-20 through `ClockOffset.pin`.

## How you notice it

Every pill that named no tone (`<pl-badge variant="success">Works</pl-badge>`) is now light and tinted, and opaque on
any row. A test that read the solid colours (`--pl-color-success` background, `-text` label) off such a badge, or
compared its ground to the translucent `--pl-color-<role>-tint` token, fails; a dynamic `tone` must be a `BadgeTone`
or a token literal. A test that looked for `pl-badge[data-boolean-cell]`, the `cms-boolean-badge-label` text or
`CmsTemplateIds.CELL_BOOLEAN_BADGE` fails to find or compile. A test that read the attention pill's colours or
padding off `pl-nav-item-metric[tone="attention"]` itself finds a transparent host: the pill is its `pl-badge` child.

## How to fix

Leave status cells, facts and labels on the floor. A count names the count kind, never the solid tone:

```html
<!-- before -->
<pl-badge variant="destructive">{{ count }}</pl-badge>
<!-- after -->
<pl-badge variant="destructive" tone="count">{{ count }}</pl-badge>
```

A pill that must shout for another reason names `tone="solid"`. A test of a style reads the reflected `data-filled`
fact (present for `solid` and `count`), never the tone token. A nav attention count stays
`<pl-nav-item-metric tone="attention">`; style or assert its `> pl-badge`, never the metric.

A badge's leading glyph is its `icon` attribute, not a slotted `pl-icon`:
`<pl-badge variant="outline" icon="lock">Works</pl-badge>`. Boolean cell tests select `[data-boolean-cell] pl-state-glyph`
and use `CmsTemplateIds.CELL_BOOLEAN_MARK`.

## Affects

Every project rendering `pl-badge` (the look changes without a code change), and projects asserting boolean list
cell markup or badge colours in tests.
