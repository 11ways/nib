---
title: Settings sections draw their groups in declared order and refuse an unnamed sibling at boot; settings nav shape; pl-icon-mark; quiet activity list detail; health band since line
date: 2026-10-20
repos: zenit, zenit-cms, plumage, zenit-widget, hohenheim
detect: Settings group '...' sits under the sections over '...' but no mount names it, Settings groups below '...' would follow class-load order, HistoryText.detail no longer compiles with two or four arguments, or a test looks for pl-state-glyph in an activity row or .stat-icon's own background
---

## What changed

- zenit-cms: a settings section (`SettingsPage.frameworkSection(key, label, groups...)`) draws its groups in the order
  it names them. They used to follow the parent's registration order, which is class-load order and varied by boot.
  The section's backend offers exactly the named groups (`SettingsEditorBackend.naming`), and the page walks groups
  only through `SettingsBackend.childGroups`. A group listed after a group it sits below orders that group's own
  level the same way: a nested level holding settings in more than one child must be named so, and a named level must
  list every child holding settings. A `SettingsPage` holding a section refuses at construction (boot) any child group
  of that section's parent that no mount names, or that two mounts both offer: the framework mount leaves that whole
  parent out, so such a group used to vanish silently. A group created after the page was built (a late module)
  refuses the next render the same way (`IllegalStateException` naming it), never drops out.
- zenit-cms: `SettingsPage.Standard.navShape(SettingsNavShape)` declares how the section list draws its rows:
  `GROUP_ROWS` (the default, unchanged: every group its own indented row) or `SECTION_ROWS` (one row per section;
  opening it loads every group of that section). Hohenheim opts into `SECTION_ROWS`.
- zenit: `HistoryText.detail(entry, reader, gate, values, place)` and the one-change overload take a
  `HistoryDetailPlace`; the two-argument `detail(entry, reader)` is gone, so every caller states its place. `LIST_ROW`
  (the activity list, a record's history feed) says nothing for a change that stored no details; `ENTRY_PAGE` (the
  entry's own page) keeps "Details not recorded".
- plumage: `pl-icon-mark` is THE tinted icon circle: `icon`, nullable `variant: BadgeVariant` (the tone's mark on the
  tone's tint; none is the grey mark on the chrome ground; `secondary` the grey mark on the grey pill's ground and
  hairline, as pl-badge's secondary pill, read from `Tone.neutralGround`; `outline` hollow in a ring),
  `size="default"|"lg"` and an optional spoken `label`. `pl-stat-card`'s corner icon, zenit-cms's activity mark
  (`cell/activity-mark`), the zenit-widget record icon and Hohenheim's attention items draw it; `.widget-record-icon`
  is gone.
- zenit-widget: a record entry's title wraps a long unbroken word (a hash, a hostname) instead of running under the
  time column.
- zenit-cms: `RecordHealth.since(lead, at)` adds a band line that reads the moment as live relative time
  (`pl-relative-time`): "Last deployed 2 hours ago". `RecordHealthState` carries `sinceLead` and `sinceAt`. The lead
  is Microcopy in the viewer's locale and always precedes the moment.

## How you notice it

- Boot fails with `Settings group 'hohenheim.foo' sits under the sections over 'hohenheim' but no mount names it: name
  it in a section or mount it on its own`, or `Settings group '...' is offered by both mount 'a' and mount 'b'`.
- `HistoryText.detail(entry, reader)`, `HistoryText.detail(entry, reader, gate, values)` and
  `HistoryText.detail(change, action, reader, gate, values)` no longer compile.
- A test reading `pl-list-item ... pl-state-glyph` in the activity list, the `background` of `pl-stat-card
  .stat-icon` (now a `pl-icon-mark`), or `.widget-record-icon` finds nothing; an activity list row no longer says
  "Details not recorded".

## How to fix

- Name every child group of a sectioned parent in exactly one section (or mount it alone with `frameworkGroup`):

```java
SettingsPage.frameworkSection("ops", label, Settings.Proxy.GROUP, Settings.Backup.GROUP)  // drawn in this order
```

- Name a sectioned group's nested groups after it, in drawing order, when more than one of them holds settings:

```java
SettingsPage.frameworkSection("ops", label, Settings.Proxy.GROUP, Settings.Proxy.Upstream.GROUP,
    Settings.Proxy.Cache.GROUP, Settings.Backup.GROUP)
```

- Pass where the detail line is drawn:

```java
// before
HistoryText.detail(entry, access);                                                  // two arguments
HistoryText.detail(entry, access, null, ViewerFieldValueText.SENTENCE);              // four arguments
// after
HistoryText.detail(entry, access, null, FieldValueText.standard(), HistoryDetailPlace.ENTRY_PAGE);
HistoryText.detail(entry, access, null, ViewerFieldValueText.SENTENCE, HistoryDetailPlace.LIST_ROW);
```

- Draw a round tinted icon with `<pl-icon-mark icon="rocket" variant="success"></pl-icon-mark>` instead of a span
  with a radius and a tint; select `pl-icon-mark` in tests.
- Opt a settings page into one row per section with `.navShape(SettingsNavShape.SECTION_ROWS)`.
- Say when something last happened on a health band with `RecordHealth.ok(headline).since(lead, instant)`, never a
  `{$at :datetime}` detail.

## Affects

Hosts with operator settings sections (Hohenheim), code calling the two-, four- or five-argument `HistoryText.detail`,
and apps drawing their own tinted icon circles (Proteus's `.proteus-big-mark`) or asserting the activity mark's
markup.
