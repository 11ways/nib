---
title: Index-fed registries are their own class; the refusing declaration scope moves to Blast
date: 2026-10-20
repos: protoblast, zenit, zenit-forms, hawkeye
detect: cannot find symbol RegistryFeed, or Models.withoutIndexWait / Models.NotYetRegistered
---

## What changed

- `RegistryFeed` is gone. Which registry reads run the autoload index is now a type fact: `Registry.autoLoaded(...)`
  and `KeyedRegistry.autoLoaded(...)` (signatures unchanged) return an index-fed class, `Registry.create(...)` and
  `KeyedRegistry.create(...)` a plain one whose reads never touch the index.
- A class-keyed registry the index fills extends the new `IndexFedClassKeyedRegistry` instead of passing
  `RegistryFeed.AUTOLOAD_INDEX` to `ClassKeyedRegistry`'s constructor, which now takes only the registry id.
  zenit's `FieldFormEntryRegistry`, zenit-forms' `ControlFactories`, `FieldDiffRegistry` and
  `FormEntryRendererRegistry`, hawkeye's `ClassPropertyAccessorRegistry` and `ClassPropertyMutatorRegistry` (their
  generated tier) and protoblast's `ShaderPrograms` now do so.
- `Blast.withoutIndexWait(work)` runs a declaration's work ahead of its first read: inside it,
  `Blast.ensureAutoLoaded()` (and so every index-fed registry read, seam read and `Models.get` miss) throws
  `IndexWaitRefused` instead of waiting. zenit's `Models.withoutIndexWait` and `Models.NotYetRegistered` are removed.

## How you notice it

- `error: cannot find symbol ... RegistryFeed`
- `error: constructor ClassKeyedRegistry in class ClassKeyedRegistry<V> cannot be applied to given types`
- `error: cannot find symbol ... withoutIndexWait(...) location: class Models` or `NotYetRegistered`

## How to fix

Before:

```java
public final class Handlers extends ClassKeyedRegistry<Handler> {
    private Handlers() {
        super(MyIds.id("handlers"), RegistryFeed.AUTOLOAD_INDEX);
    }
}
```

After:

```java
public final class Handlers extends IndexFedClassKeyedRegistry<Handler> {
    private Handlers() {
        super(MyIds.id("handlers"));
    }
}
```

A `ClassKeyedRegistry(id, RegistryFeed.DECLARATIONS)` becomes `ClassKeyedRegistry(id)`. A registry holding both an
index-fed and a declaration-fed tier keeps the second in its own `ClassKeyedRegistry` subclass (hawkeye's
`FallbackTier`). Code calling `Registry.autoLoaded`/`KeyedRegistry.autoLoaded` needs no change.

Before: `try { Models.withoutIndexWait(work); } catch (Models.NotYetRegistered e) { ... }`
After: `try { Blast.withoutIndexWait(work); } catch (IndexWaitRefused e) { ... }` (both in
`be.elevenways.protoblast.common`).

## Affects

Projects declaring a class-keyed registry the autoload index fills, and code resolving a declaration ahead of its
first read through zenit's former `Models.withoutIndexWait`.
