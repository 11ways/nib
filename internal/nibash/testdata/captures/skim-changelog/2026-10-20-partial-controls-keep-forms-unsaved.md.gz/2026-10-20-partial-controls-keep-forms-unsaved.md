---
title: A control showing what its submission drops keeps its tracked form unsaved
date: 2026-10-20
repos: protoblast, hawkeye, plumage
detect: A form with a half-typed custom control now asks before leaving (data-hwk-unsaved set while values are unchanged)
---

## What changed

hawkeye `FormChanges` counts a control the reader edited since the form loaded that answers
`TakesFormValues.submissionHoldsAll()` false as unsaved, so leaving asks; typing it back to its loaded state reads
clean again, and a control already partial at load that nobody touched leaves the form clean. An edit inside a popup
portalled from a control in the form counts as that control's edit. plumage's pl-select answers false for an
uncommitted tag or freeText search text; pl-date-field (a half-typed date) and pl-date-picker (one end of a range
picked) announce edits that move no value with `PlumageField.announceEdit`.

An outside press, the click on a link included, closes pl-select's and pl-date-picker's popup and keeps the
uncommitted text (a typed tag, a half-picked range): reopening shows it and the form stays unsaved; only Escape
(`Layer.discardsInput`, the `DismissReason` vocabulary), a clear or a commit throws it away. Escape in a
single-mode freeText pl-select no longer commits the typed text. Typing in a pl-date-picker while a save is on its
way is now carried into the redrawn form with no question: `FormChanges` reads a form's controls through
`DominoHtmlFormElement.getSubmittableElements()`, never a `[name]` query.

## How you notice it

A browser test that half-types a date, leaves a tag or freeText search uncommitted, or picks one range endpoint in a
tracked form and then navigates now gets the leave question (`NavigationChrome.LEAVE_UNSAVED`) and stays on the page.
A test expecting an outside click to empty a tag or range now finds it still there, and one expecting Escape to
commit freeText finds the old value; a test expecting a question for date-picker typing during a save gets none.

## How to fix

A test that means to leave accepts the dialog:

```java
page.onceDialog(Dialog::accept);
```

A custom `TakesFormValues` control whose `submissionHoldsAll()` answer changes without its value changing dispatches
a bubbling `input` event on itself (`PlumageField.announceEdit(this)` in plumage templates), or the tracker never
hears it.

## Affects

Projects with tracked forms (zenit-forms bodies, `Form.trackChanges`) using these plumage controls, and custom
form-associated controls implementing `submissionHoldsAll()`.
